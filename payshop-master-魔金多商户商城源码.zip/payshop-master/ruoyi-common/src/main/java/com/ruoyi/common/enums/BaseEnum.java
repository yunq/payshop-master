package com.ruoyi.common.enums;

public interface BaseEnum<K> {
    K code();

    String desc();
}
