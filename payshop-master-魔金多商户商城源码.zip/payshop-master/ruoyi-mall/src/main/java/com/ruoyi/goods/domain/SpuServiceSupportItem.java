package com.ruoyi.goods.domain;

/**
 * Created by 魔金商城 on 18/1/2.
 * 商品服务支付查询条件
 */
public enum SpuServiceSupportItem {
    SERVICE_SUPPORT
}
